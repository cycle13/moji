#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
author:     yetao.lu
date:       2018/8/13
description:
"""

if __name__ == "__main__":
    print ''
